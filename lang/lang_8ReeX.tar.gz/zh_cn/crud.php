<?php

return [
    'enter_item_name' => '请输入:item名称',
    'item_managment' => ':Item管理',
    'add_new_item' => '新增:item',
    'new_item' => '新:item',
    'back' => '返回',
    'item_has_been_added' => ':Item已添加',
    'edit_item_name' => '编辑:item :name',
    'item_has_been_updated' => ':Item已更新',
    'item_has_been_removed' => ':Item已删除',
    'item_has_items_associated' => ':Item有关联的项目。请先移除所有关联项后再删除此:item。',
    'edit' => '编辑',
    'delete' => '删除',
    'actions' => '操作',
    'no_items' => '暂无:items…',
    'clear_filters' => '清除筛选',
    'download_report' => '下载报表',
    'filter' => '筛选',
];
