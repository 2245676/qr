<?php

return [
    'customer_phone_number' => '客户电话号码',
    'delivery_area_name' => '配送区域名称',
    'client_phone' => '客户电话号码',
    'client_name' => '客户名称',
];

